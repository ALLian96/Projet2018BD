CREATE VIEW LesDossiers (nDos, montant) as
    with X as (select noDos, prixZone from lesZones natural join LesPlaces natural join LesTickets)
    select noDos, sum(prixZone) as montant from X group by noDos;

