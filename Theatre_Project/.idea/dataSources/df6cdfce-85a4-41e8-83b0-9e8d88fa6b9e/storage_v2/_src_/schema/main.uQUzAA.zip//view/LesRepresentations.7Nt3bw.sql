CREATE VIEW LesRepresentations (noSpec, dateRep, nbPlaces) as
    with Y as(select noSpec,dateRep from LesRepresentations_base
EXCEPT select noSpec,dateRep from LesRepresentations_base natural join LesTickets),
 X as (
       select count(noPlace) as placeTotal from LesPlaces
       )
select noSpec,dateRep,placeTotal-count(noPlace) as placeDispo from LesRepresentations_base natural join LesTickets natural join X
              group by noSpec,dateRep
union select noSpec,dateRep,15 from Y;

