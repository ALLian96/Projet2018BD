#!/bin/bash
pyuic5 fct_comp_1.ui -o fct_comp_1.py
pyuic5 fct_comp_2.ui -o fct_comp_2.py
pyuic5 fct_comp_3.ui -o fct_comp_3.py
pyuic5 fct_comp_4.ui -o fct_comp_4.py
pyuic5 fct_fournie_1.ui -o fct_fournie_1.py
pyuic5 fct_fournie_2.ui -o fct_fournie_2.py
pyuic5 tablesData.ui -o tablesData.py
pyuic5 mainWindow.ui -o mainWindow.py